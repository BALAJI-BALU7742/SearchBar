import React, { useState, useEffect } from 'react';
import './App.css';

const App = () => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    // Fetch country data from a JSON file or API
    fetch('/data/countries.json')
      .then(response => response.json())
      .then(data => setCountries(data));
  }, []);

  useEffect(() => {
    if (query) {
      const filteredSuggestions = countries.filter(country =>
        country.name.toLowerCase().includes(query.toLowerCase()) ||
        country.capital.toLowerCase().includes(query.toLowerCase())
      );
      setSuggestions(filteredSuggestions);
    } else {
      setSuggestions([]);
    }
  }, [query, countries]);

  return (
    <div className="App">
      <h1>Fast Finder Search Bar</h1>
      <input
        type="text"
        placeholder="Search for a country by name or capital"
        value={query}
        onChange={e => setQuery(e.target.value)}
      />
      <ul>
        {suggestions.map((suggestion, index) => (
          <li key={index}>
            {suggestion.name} - {suggestion.capital}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
